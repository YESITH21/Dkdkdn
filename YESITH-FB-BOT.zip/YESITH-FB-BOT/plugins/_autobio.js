/*let handler = m => m 
handler.all = async function (m) {
let setting = global.db.data.settings[this.user.jid]
	
let _uptime = process.uptime() * 1000
let _muptime
if (process.send) { process.send('uptime')
_muptime = await new Promise(resolve => { process.once('message', resolve) 
setTimeout(resolve, 2000) }) * 1000}
let uptime = clockString(_uptime)
let bio = `${global.packname} ║ ✅ ${uptime} ⌛ ║ ⒷⒷ  ${[`𓃵𖧹 ☆𝑩𝒓𝒐𝒍𝒚-𝑩𝒐𝒕☆ ✅ 𝘈𝘤𝘵𝘪𝘷𝘪𝘥𝘢𝘥: 00 ✯ 00 ✰ 06 ☆ 57 ⌛ ꨄ︎𝐏𝐚𝐫𝐚 𝐕𝐞𝐫 𝐌𝐢𝐬 𝐂𝐨𝐦𝐚𝐧𝐝𝐨𝐬 𝐄𝐬𝐜𝐫𝐢𝐛𝐞 .menu 𝘉𝘺: 𝘈𝘯𝘨𝘦𝘭𝘍𝘢𝘤𝘩𝘳𝘦𝘳𝘰ᰔᩚ `].getRandom()}`
await this.updateProfileStatus(bio).catch(_ => _)
//await this.updateProfilePicture(gataImg.getRandom()).catch(_ => _)
setting.status = new Date() * 1
} 
export default handler

function clockString(ms) {
  let d = isNaN(ms) ? '--' : Math.floor(ms / 86400000)
  let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000) % 24
  let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
  let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
  return [d, ' » ', h, ' ・ ', m, ' ・ ', s].map(v => v.toString().padStart(2, 0)).join('') 
} */
