### Pagos 𝘺 𝘋𝘰𝘯𝘢𝘤𝘪𝘰𝘯𝘦𝘴 realizados para la utilización de bot en servidor.
#### ✅ = 𝘚𝘰𝘭𝘪𝘤𝘪𝘵𝘶𝘥 activ𝘢.
#### ⚪ = Sin información.
 
| USUARIO          |   INICIO                | FIN    | ESTADO
| ------------     | ------------            | ------------| ------------
| [**Desconocido**](+57 322 687 67 04)        | `14 Abril` | `18 Mayo` | ❌
| [**ANIIIIII**](+57 322 687 67 04)        | `1 Mayo` | `1 Enero` | ✅
| ⚪        | ⚪               |  ⚪ | ⚪

